package family.domain;


public enum Sex {

    MALE, FEMALE, OTHER, NOT_KNOWN;
}
