package family.domain;

import flexjson.JSONDeserializer;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.validation.constraints.Size;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.jpa.activerecord.RooJpaActiveRecord;
import org.springframework.roo.addon.json.RooJson;
import org.springframework.roo.addon.tostring.RooToString;

@RooJavaBean
@RooToString
@RooJson
@RooJpaActiveRecord(finders = { "findPeopleByNameLike", "findPeopleByMotherAndFather" })
public class Person {

    private static Logger logger = LoggerFactory.getLogger(Person.class);

    @Size(max = 30)
    private String name;

    @ManyToOne(fetch = FetchType.LAZY, cascade = { javax.persistence.CascadeType.PERSIST, javax.persistence.CascadeType.REFRESH })
    private family.domain.Person father;

    @ManyToOne(fetch = FetchType.LAZY, cascade = { javax.persistence.CascadeType.PERSIST, javax.persistence.CascadeType.REFRESH })
    private family.domain.Person mother;

    @ManyToMany(cascade = { javax.persistence.CascadeType.PERSIST, javax.persistence.CascadeType.REFRESH }, fetch = FetchType.LAZY)
    private Set<family.domain.Person> children = new HashSet<family.domain.Person>();

    public void setFather(family.domain.Person father) {
        this.father = father;
        this.father.getChildren().add(this);
    }

    public void setMother(family.domain.Person mother) {
        this.mother = mother;
        this.mother.getChildren().add(this);
    }

    public void removeMother(family.domain.Person mother) {
        mother.getChildren().remove(this);
        this.setMother(null);
    }

    public void removeFather(family.domain.Person father) {
    	father.getChildren().remove(this);
        this.setFather(null);
    }
}
