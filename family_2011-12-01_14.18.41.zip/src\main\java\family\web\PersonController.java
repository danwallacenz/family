package family.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.roo.addon.web.mvc.controller.json.RooWebJson;
import org.springframework.roo.addon.web.mvc.controller.scaffold.RooWebScaffold;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import family.domain.Person;

@RooWebJson(jsonObject = Person.class)
@Controller
@RequestMapping("/people")
@RooWebScaffold(path = "people", formBackingObject = Person.class)
public class PersonController {
	
	private static Logger log = LoggerFactory.getLogger(PersonController.class);
	
//    @RequestMapping(method = RequestMethod.POST, headers = "Accept=application/json")
//    public ResponseEntity<java.lang.String> createFromJson(@RequestBody java.lang.String json) {
//    	log.info("******** createFromJson :" + json);
//    	Person person = Person.fromJsonToPerson(json);
//        log.info("******** createFromJson " + person + ":" + json);
//        log.info("******** mother: " + person.getMother());
//        log.info("******** father: " + person.getFather());
//        person.persist();
//        HttpHeaders headers = new HttpHeaders();
//        headers.add("Content-Type", "application/text");
//        return new ResponseEntity<String>(headers, HttpStatus.CREATED);
//    }
}
