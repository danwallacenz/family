package family.domain;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.validation.constraints.Size;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.jpa.activerecord.RooJpaActiveRecord;
import org.springframework.roo.addon.json.RooJson;
import org.springframework.roo.addon.tostring.RooToString;

import flexjson.JSONDeserializer;

@RooJavaBean
@RooToString
@RooJpaActiveRecord
@RooJson
public class Person {

	private static Logger logger = LoggerFactory.getLogger(Person.class);
	
//    public static Person fromJsonToPerson(java.lang.String json) {
//    	Person person = new JSONDeserializer<Person>().use(null, Person.class).deserialize(json);
//    	logger.info("******** fromJsonToPerson " + person);
//    	return person;
//    }
	
    @Size(max = 30)
    private String name;

    @ManyToOne(fetch = FetchType.LAZY, cascade = {CascadeType.PERSIST, CascadeType.REFRESH})
    private family.domain.Person father;

    @ManyToOne(fetch = FetchType.LAZY, cascade = {CascadeType.PERSIST, CascadeType.REFRESH})
    private family.domain.Person mother;
    
    @ManyToMany(cascade = {CascadeType.PERSIST, CascadeType.REFRESH}, fetch = FetchType.LAZY)
    private Set<family.domain.Person> children = new HashSet<family.domain.Person>();

    
//    public void setName(java.lang.String name) {
//    	logger.info("******** setting name to " + name);
//        this.name = name;
//    }    
    
    public void setFather(Person father) {
        this.father = father;
        this.father.getChildren().add(this);
    }

    public void setMother(Person mother) {
        this.mother = mother;
        this.mother.getChildren().add(this);
    }
    
    public void addChild(Person child) {
        this.getChildren().add(child);
    }

    public void removeChild(Person child) {
    	this.getChildren().remove(child);
    }
    
    public void removeMother(Person mother) {
    	this.setMother(null);
    }
    
    public void removeFather(Person father) {
    	this.setFather(null);
    }
}
