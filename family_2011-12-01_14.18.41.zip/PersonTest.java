package family.domain;

import junit.framework.Assert;

import org.junit.Test;

import flexjson.JSONDeserializer;
import flexjson.JSONSerializer;


public class PersonTest {

    public Person fromJsonToPerson(java.lang.String json) {
        return new JSONDeserializer<Person>().use(null, Person.class).deserialize(json);
    }
	
    public java.lang.String toJson(Person person) {
        return new JSONSerializer().exclude("*.class").serialize(person);
    }
    
    @Test
    public void testJSONDeserializer() {
    	String json = "{\"father\":null,\"id\":2,\"mother\":null,\"name\":\"dan\",\"version\":0}";
    	Person person = fromJsonToPerson(json);
    	System.out.println(person);
    	String toJson = toJson(person);
    	System.out.println(toJson);
    	Assert.assertEquals(json, toJson);
    	
    	
    }
}
